# WINE AI — Android Kotlin starter

Proyek awal asisten suara WINE untuk Android. Target pengujian awal: Vivo Y12s.

## Fitur pada source versi Hybrid
- Tombol untuk mengaktifkan / mematikan layanan pendengar.
- SpeechRecognizer Bahasa Indonesia untuk mendeteksi frasa yang memuat "WINE".
- Frasa "WINE, kamu di mana?" memulai alarm berulang; tombol di aplikasi menghentikannya.
- Text-to-Speech Bahasa Indonesia.
- Perekam suara lokal (M4A), daftar rekaman, dan pemutaran rekaman pilihan.
- Pengaturan volume pemutaran dan kecepatan Text-to-Speech.
- Tampilan WINE AI Chat berbasis teks.
- Mode offline sederhana dengan beberapa respons lokal (bukan model AI generatif).
- Mode online dengan Groq dan Gemini melalui endpoint HTTPS resmi yang kompatibel dengan format OpenAI Chat Completions. Bisa memilih Groq, Gemini, atau fallback Groq lalu Gemini. Model dan API key dapat diatur dari aplikasi.
- Riwayat chat sementara selama aplikasi berjalan dan tombol membacakan jawaban.
- GitHub Actions untuk membangun APK debug.

## Batasan penting
- Wake word ini memakai pengenalan ucapan Android, bukan mesin wake-word khusus yang selalu aktif. Akurasi dan ketersediaan tergantung layanan pengenalan suara perangkat dan sering memerlukan internet.
- Android/Vivo dapat membatasi mikrofon saat aplikasi di latar belakang atau saat hemat baterai aktif. Mulai layanan dari aplikasi saat layar terbuka dan beri izin mikrofon/notifikasi.
- Ini bukan jaminan mendengarkan 24 jam. Uji dahulu di perangkat.
- Rekaman pilihan diputar sebagai audio biasa; tidak ada voice cloning.
- Pengaturan kecepatan hanya berlaku untuk Text-to-Speech, bukan mempercepat/memperlambat file rekaman.
- Mode offline bukan AI generatif dan hanya memberi respons sederhana berbasis kata kunci.
- Mode online memerlukan API key Groq dan/atau Gemini milik pengguna. Kuota, model aktif, harga, dan free tier mengikuti kebijakan penyedia dan dapat berubah. Dokumentasi: https://console.groq.com/docs/api-reference dan https://ai.google.dev/gemini-api/docs/openai.
- API key yang dimasukkan disimpan di penyimpanan privat aplikasi, tetapi tetap tidak aman sepenuhnya pada perangkat yang sudah di-root atau jika APK dibongkar. Untuk aplikasi publik, sebaiknya gunakan backend/proxy milik sendiri dan jangan tanam API key rahasia di APK.
- Source ini belum diuji build atau dijalankan pada Vivo Y12s. Jalankan GitHub Actions dan kirim log error jika build gagal.

## Build APK dari HP Android melalui GitHub
1. Buat repository GitHub bernama `WINE-AI` dan pilih Public atau Private.
2. Di HP, buka repository melalui Chrome dan pilih **Add file > Upload files**.
3. Upload seluruh isi folder proyek ini (jangan upload folder ZIP sebagai satu file). Pastikan `.github/workflows/android.yml` ikut ter-upload.
4. Commit ke branch `main`.
5. Buka tab **Actions** > workflow **Build WINE Android APK** > tunggu sampai tanda centang hijau.
6. Buka hasil run yang berhasil, cari bagian **Artifacts**, lalu unduh `WINE-AI-debug-apk`.
7. Ekstrak ZIP artifact dan pasang `app-debug.apk`. Android mungkin meminta izin instal aplikasi dari sumber tersebut.

## Jika build gagal
Buka run Actions yang merah, pilih job `build`, lalu salin bagian error pertama (bukan token/password) untuk diperiksa. Jangan pernah mengirim password atau token GitHub melalui chat.

## Catatan teknis
- AGP 8.7.3, Kotlin 2.0.21, Gradle 8.9, JDK 17, compileSdk 35.
- Workflow menginstal Gradle langsung; tidak membutuhkan `gradlew` atau file wrapper JAR.
- Build ini menghasilkan APK debug yang dapat dipasang untuk pengujian, bukan APK rilis bertanda tangan untuk distribusi.
