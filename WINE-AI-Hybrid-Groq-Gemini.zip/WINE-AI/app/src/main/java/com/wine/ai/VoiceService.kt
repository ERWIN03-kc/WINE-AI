package com.wine.ai

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.media.AudioManager
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.speech.RecognitionListener
import android.speech.SpeechRecognizer
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.core.app.NotificationCompat
import java.util.Locale

class VoiceService : Service(), RecognitionListener, TextToSpeech.OnInitListener {
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var alarm: MediaPlayer? = null
    private var listening = false
    private var restarting = false

    override fun onCreate() {
        super.onCreate()
        createChannel()
        tts = TextToSpeech(this, this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                startForeground(NOTIFICATION_ID, notification())
                beginListening()
            }
            ACTION_STOP -> stopSelf()
            ACTION_ALARM -> startAlarm()
            ACTION_ALARM_STOP -> stopAlarm()
        }
        return START_NOT_STICKY
    }

    private fun beginListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            speak("Pengenalan suara tidak tersedia di perangkat ini.")
            stopSelf()
            return
        }
        listening = true
        restarting = false
        listenOnce()
    }

    private fun listenOnce() {
        if (!listening) return
        try {
            recognizer?.destroy()
            recognizer = SpeechRecognizer.createSpeechRecognizer(this).also {
                it.setRecognitionListener(this)
            }
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "id-ID")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
            }
            recognizer?.startListening(intent)
        } catch (_: Exception) {
            scheduleRestart()
        }
    }

    override fun onResults(results: Bundle?) {
        val texts = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
        handleSpeech(texts.joinToString(" ").lowercase(Locale("id", "ID")))
        scheduleRestart()
    }

    override fun onPartialResults(partialResults: Bundle?) {
        val text = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            ?.lowercase(Locale("id", "ID")) ?: return
        if (text.contains("wine") && (text.contains("kamu di mana") || text.contains("dimana"))) {
            startAlarm()
        } else if (text.contains("wine") && text.length < 24) {
            speak("Iya, aku di sini. Ada yang bisa dibantu?")
        }
    }

    private fun handleSpeech(text: String) {
        if (text.contains("wine") && (text.contains("kamu di mana") || text.contains("dimana"))) {
            startAlarm()
        } else if (text.contains("wine")) {
            speak("Hadir! WINE online. Ada misi apa?")
        }
    }

    private fun scheduleRestart() {
        if (!listening || restarting) return
        restarting = true
        android.os.Handler(mainLooper).postDelayed({
            restarting = false
            if (listening) listenOnce()
        }, 650)
    }

    private fun startAlarm() {
        try {
            stopAlarm()
            val uri = android.media.RingtoneManager.getDefaultUri(android.media.RingtoneManager.TYPE_ALARM)
                ?: android.media.RingtoneManager.getDefaultUri(android.media.RingtoneManager.TYPE_RINGTONE)
            alarm = MediaPlayer().apply {
                setDataSource(this@VoiceService, uri)
                isLooping = true
                setAudioStreamType(AudioManager.STREAM_ALARM)
                prepare()
                start()
            }
            updateNotification("Alarm pencari HP berbunyi")
        } catch (_: Exception) {
            speak("Alarm tidak bisa diputar. Periksa volume alarm perangkat.")
        }
    }

    private fun stopAlarm() {
        try { alarm?.stop() } catch (_: Exception) {}
        alarm?.release()
        alarm = null
        updateNotification("Pendengar WINE aktif")
    }

    private fun speak(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "wine-service-${System.currentTimeMillis()}")
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) tts?.language = Locale("id", "ID")
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL_ID, "WINE Voice Assistant", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun notification(): Notification {
        val stopIntent = Intent(this, VoiceService::class.java).setAction(ACTION_STOP)
        val pending = PendingIntent.getService(this, 2, stopIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("WINE sedang mendengarkan")
            .setContentText("Ketuk Matikan dari aplikasi untuk berhenti")
            .setOngoing(true)
            .addAction(0, "Matikan", pending)
            .build()
    }

    private fun updateNotification(message: String) {
        val n = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("WINE AI")
            .setContentText(message)
            .setOngoing(listening)
            .build()
        getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, n)
    }

    override fun onError(error: Int) { scheduleRestart() }
    override fun onReadyForSpeech(params: Bundle?) {}
    override fun onBeginningOfSpeech() {}
    override fun onRmsChanged(rmsdB: Float) {}
    override fun onBufferReceived(buffer: ByteArray?) {}
    override fun onEndOfSpeech() {}
    override fun onEvent(eventType: Int, params: Bundle?) {}

    override fun onDestroy() {
        listening = false
        recognizer?.destroy()
        recognizer = null
        stopAlarm()
        tts?.shutdown()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_START = "com.wine.ai.START"
        const val ACTION_STOP = "com.wine.ai.STOP"
        const val ACTION_ALARM = "com.wine.ai.ALARM"
        const val ACTION_ALARM_STOP = "com.wine.ai.ALARM_STOP"
        private const val CHANNEL_ID = "wine_voice_channel"
        private const val NOTIFICATION_ID = 71
    }
}
