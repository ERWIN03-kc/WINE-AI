package com.wine.ai

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.io.File
import java.util.Locale
import java.net.HttpURLConnection
import java.net.URL
import java.io.OutputStreamWriter
import java.util.concurrent.Executors
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var tts: TextToSpeech
    private lateinit var status: TextView
    private lateinit var recordings: Spinner
    private var recorder: MediaRecorder? = null
    private var player: MediaPlayer? = null
    private var selectedRecording: File? = null
    private var volume = 0.8f
    private var speechRate = 1.0f
    private val requestCode = 101
    private val audioDir by lazy { File(filesDir, "wine-voices").apply { mkdirs() } }
    private val chatExecutor = Executors.newSingleThreadExecutor()
    private val chatHistory = mutableListOf<JSONObject>()
    private lateinit var chatTranscript: TextView
    private lateinit var chatInput: EditText
    private lateinit var chatStatus: TextView
    private var onlineMode = false
    private val prefs by lazy { getSharedPreferences("wine_chat", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildScreen()
        requestNeededPermissions()
    }

    private fun buildScreen() {
        val scroll = ScrollView(this)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 34, 28, 32)
            setBackgroundColor(0xFF101522.toInt())
        }
        scroll.addView(layout)
        setContentView(scroll)

        fun label(text: String, size: Float = 16f): TextView =
            TextView(this).apply {
                this.text = text
                textSize = size
                setTextColor(0xFFF3F5FF.toInt())
                setPadding(0, 12, 0, 12)
            }

        fun button(text: String, action: () -> Unit) {
            val b = Button(this).apply { this.text = text; isAllCaps = false }
            b.setOnClickListener { action() }
            layout.addView(b, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 8 })
        }

        layout.addView(label("WINE AI", 30f))
        layout.addView(label("Asisten suara pribadi • versi awal"))
        status = label("Status: belum aktif")
        layout.addView(status)

        // Hybrid AI chat: offline replies always work; online uses a user-configured OpenAI-compatible endpoint.
        layout.addView(label("WINE AI CHAT", 23f))
        layout.addView(label("Ngobrol lewat teks. Online mendukung Groq + Gemini; offline memberi jawaban lokal sederhana."))
        chatStatus = label("Mode: OFFLINE • jawaban lokal sederhana")
        layout.addView(chatStatus)
        chatTranscript = label("WINE: Halo! Gue WINE. Mau ngobrol apa hari ini?", 15f)
        chatTranscript.setBackgroundColor(0xFF1B2638.toInt())
        chatTranscript.setPadding(16, 16, 16, 16)
        layout.addView(chatTranscript, LinearLayout.LayoutParams(-1, -2))
        chatInput = EditText(this).apply {
            hint = "Tulis pesan ke WINE…"
            setHintTextColor(0xFF9AA8C0.toInt())
            setTextColor(0xFFFFFFFF.toInt())
            setBackgroundColor(0xFF25334A.toInt())
            minLines = 2
            maxLines = 4
            setPadding(14, 10, 14, 10)
        }
        layout.addView(chatInput, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 10 })
        button("Kirim pesan") { sendChatMessage() }
        button("Mode OFFLINE / ONLINE") { toggleChatMode() }
        button("Pengaturan Groq + Gemini") { showOnlineSettings() }
        button("Bacakan jawaban terakhir") {
            val last = chatHistory.lastOrNull()?.optString("content")
            if (!last.isNullOrBlank()) speak(last) else speak("Belum ada jawaban untuk dibacakan.")
        }
        button("Hapus percakapan") {
            chatHistory.clear()
            chatTranscript.text = "WINE: Percakapan dibersihkan. Mau mulai dari mana?"
        }

        button("Aktifkan pendengar WINE") { startListener() }
        button("Matikan pendengar") { stopListener() }
        button("Tes suara WINE") { speak("Halo! WINE siap membantu. Jangan lupa, aku bukan alarm tetangga.") }
        button("WINE, kamu di mana? (tes alarm)") { startAlarm() }
        button("Hentikan alarm") { stopAlarm() }

        layout.addView(label("Rekam suara sendiri"))
        button("Mulai rekam") { startRecording() }
        button("Simpan rekaman") { stopRecording() }
        recordings = Spinner(this)
        layout.addView(recordings)
        button("Putar rekaman pilihan") { playSelectedRecording() }
        button("Gunakan rekaman untuk sapaan WINE") {
            val file = selectedRecording
            if (file != null && file.exists()) {
                stopPlayer()
                player = MediaPlayer().apply {
                    setDataSource(file.absolutePath)
                    setVolume(volume, volume)
                    prepare()
                    start()
                }
                status.text = "Status: memutar suara pilihan"
            } else speak("Belum ada rekaman yang dipilih.")
        }
        refreshRecordings()

        layout.addView(label("Pengaturan suara"))
        layout.addView(label("Volume"))
        val volumeBar = SeekBar(this).apply {
            max = 100
            progress = 80
            setOnSeekBarChangeListener(simpleSeekListener { volume = it / 100f })
        }
        layout.addView(volumeBar)
        layout.addView(label("Kecepatan bicara (Text-to-Speech)"))
        val speedBar = SeekBar(this).apply {
            max = 150
            progress = 50
            setOnSeekBarChangeListener(simpleSeekListener {
                speechRate = 0.5f + it / 100f
                if (::tts.isInitialized) tts.setSpeechRate(speechRate)
            })
        }
        layout.addView(speedBar)
        layout.addView(label("Catatan: rekaman suara diputar apa adanya. Pengaturan kecepatan TTS tidak mengubah kecepatan file rekaman."))
        layout.addView(label("Izin mikrofon diperlukan. Wake word latar belakang memakai layanan Android dan dapat dibatasi oleh penghemat baterai Vivo."))
    }

    private fun appendChat(who: String, message: String) {
        val old = chatTranscript.text.toString()
        chatTranscript.text = if (old.isBlank()) "$who: $message" else "$old\n\n$who: $message"
    }

    private fun sendChatMessage() {
        val message = chatInput.text.toString().trim()
        if (message.isEmpty()) return
        chatInput.setText("")
        appendChat("LU", message)
        chatHistory.add(JSONObject().put("role", "user").put("content", message))
        chatStatus.text = if (onlineMode) "Mode: ONLINE • menghubungi AI…" else "Mode: OFFLINE • berpikir…"
        if (onlineMode) {
            val groqKey = prefs.getString("groq_key", "").orEmpty().trim()
            val geminiKey = prefs.getString("gemini_key", "").orEmpty().trim()
            val provider = prefs.getString("provider", "both").orEmpty()
            if ((provider == "groq" && groqKey.isBlank()) || (provider == "gemini" && geminiKey.isBlank()) ||
                (provider == "both" && groqKey.isBlank() && geminiKey.isBlank())) {
                val reply = "API key belum diisi. Buka Pengaturan Groq + Gemini untuk mengatur Groq dan/atau Gemini."
                appendChat("WINE", reply); chatHistory.add(JSONObject().put("role", "assistant").put("content", reply))
                chatStatus.text = "Mode: ONLINE • API key belum diatur"
                return
            }
            val historySnapshot = chatHistory.map { JSONObject(it.toString()) }
            chatExecutor.execute {
                try {
                    val reply = requestConfiguredProvider(provider, groqKey, geminiKey, historySnapshot)
                    runOnUiThread {
                        appendChat("WINE", reply)
                        chatHistory.add(JSONObject().put("role", "assistant").put("content", reply))
                        chatStatus.text = "Mode: ONLINE • AI tersambung"
                        speak(reply)
                    }
                } catch (e: Exception) {
                    runOnUiThread {
                        val message = "Koneksi AI gagal (${e.localizedMessage ?: "error jaringan"}). Periksa internet, API key, model, atau kuota."
                        appendChat("WINE", message)
                        chatHistory.add(JSONObject().put("role", "assistant").put("content", message))
                        chatStatus.text = "Mode: ONLINE • koneksi gagal"
                    }
                }
            }
        } else {
            val reply = offlineReply(message)
            appendChat("WINE", reply)
            chatHistory.add(JSONObject().put("role", "assistant").put("content", reply))
            chatStatus.text = "Mode: OFFLINE • jawaban lokal sederhana"
            speak(reply)
        }
    }

    private fun offlineReply(message: String): String {
        val q = message.lowercase(Locale("id", "ID"))
        return when {
            q.contains("nama") -> "Nama gue WINE, asisten digital yang lagi lu bangun. Ada yang bisa gue bantu?"
            q.contains("siapa") && (q.contains("kamu") || q.contains("lu")) -> "Gue WINE, asisten digital buatan proyek lu. Mode offline gue masih punya kemampuan terbatas."
            q.contains("jam") || q.contains("tanggal") -> "Gue belum punya akses jam dan tanggal langsung di versi ini. Cek jam perangkat lu dulu, ya."
            q.contains("halo") || q.contains("hai") || q.contains("hello") -> "Halo juga! Gimana kabar lu hari ini? Ada misi buat WINE?"
            q.contains("terima kasih") || q.contains("makasih") -> "Sama-sama! WINE siap bantu lagi kalau dibutuhkan."
            q.contains("bantuan") || q.contains("fitur") -> "Gue bisa ngobrol sederhana secara offline, membacakan jawaban, merekam suara, dan menjalankan tes alarm pencari HP. Untuk jawaban yang lebih pintar, atur koneksi AI online."
            q.contains("sedih") || q.contains("capek") -> "Kedengarannya hari lu lagi berat. Mau cerita bagian mana yang bikin capek? Gue bisa nemenin ngobrol, walau kemampuan offline gue terbatas."
            else -> "Gue menangkap pesan lu: ‘$message’. Saat ini gue sedang di mode offline sederhana, jadi belum bisa memahami semua topik seperti AI generatif. Aktifkan mode online dan atur endpoint AI untuk jawaban yang lebih luas."
        }
    }

    private fun toggleChatMode() {
        onlineMode = !onlineMode
        chatStatus.text = if (onlineMode) "Mode: ONLINE • perlu endpoint AI" else "Mode: OFFLINE • jawaban lokal sederhana"
    }

    private fun showOnlineSettings() {
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 8, 24, 0) }
        fun field(hintText: String, value: String = "", password: Boolean = false): EditText {
            return EditText(this).apply {
                hint = hintText; setText(value)
                if (password) inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            }.also { panel.addView(it) }
        }
        val providerLabel = TextView(this).apply { text = "Penyedia AI"; textSize = 14f }
        panel.addView(providerLabel)
        val provider = Spinner(this)
        val providerNames = listOf("Groq + Gemini (fallback otomatis)", "Groq saja", "Gemini saja")
        provider.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, providerNames)
        provider.setSelection(when (prefs.getString("provider", "both")) { "groq" -> 1; "gemini" -> 2; else -> 0 })
        panel.addView(provider)
        val groqKey = field("Groq API key", prefs.getString("groq_key", "").orEmpty(), true)
        val groqModel = field("Model Groq", prefs.getString("groq_model", "llama-3.3-70b-versatile").orEmpty())
        val geminiKey = field("Gemini API key", prefs.getString("gemini_key", "").orEmpty(), true)
        val geminiModel = field("Model Gemini", prefs.getString("gemini_model", "gemini-2.5-flash").orEmpty())
        val note = TextView(this).apply {
            text = "Groq dan Gemini memakai endpoint HTTPS resmi. Mode gabungan mencoba Groq dahulu lalu Gemini jika Groq gagal. API key disimpan lokal untuk uji pribadi; jangan bagikan APK yang berisi key. Untuk aplikasi publik, pindahkan key ke backend sendiri. Kuota dan model tersedia mengikuti akun penyedia."
            textSize = 12f
        }
        panel.addView(note)
        android.app.AlertDialog.Builder(this)
            .setTitle("Pengaturan AI Groq + Gemini")
            .setView(panel)
            .setPositiveButton("Simpan") { _, _ ->
                val selected = when (provider.selectedItemPosition) { 1 -> "groq"; 2 -> "gemini"; else -> "both" }
                prefs.edit().putString("provider", selected)
                    .putString("groq_key", groqKey.text.toString().trim())
                    .putString("groq_model", groqModel.text.toString().trim())
                    .putString("gemini_key", geminiKey.text.toString().trim())
                    .putString("gemini_model", geminiModel.text.toString().trim()).apply()
                chatStatus.text = "Pengaturan AI disimpan • pilih mode ONLINE untuk mencoba"
            }
            .setNegativeButton("Batal", null).show()
    }

    private fun requestConfiguredProvider(provider: String, groqKey: String, geminiKey: String, history: List<JSONObject>): String {
        val groqModel = prefs.getString("groq_model", "llama-3.3-70b-versatile").orEmpty().trim()
        val geminiModel = prefs.getString("gemini_model", "gemini-2.5-flash").orEmpty().trim()
        var firstError: Exception? = null
        if (provider == "groq" || provider == "both") {
            if (groqKey.isNotBlank()) {
                try {
                    return requestChatCompletion("https://api.groq.com/openai/v1/chat/completions", groqModel, groqKey, history)
                } catch (e: Exception) { firstError = e }
            } else if (provider == "groq") throw IllegalStateException("Groq API key belum diisi")
        }
        if (provider == "gemini" || provider == "both") {
            if (geminiKey.isNotBlank()) {
                try {
                    return requestChatCompletion("https://generativelanguage.googleapis.com/v1beta/openai/chat/completions", geminiModel, geminiKey, history)
                } catch (e: Exception) {
                    if (firstError != null) throw IllegalStateException("Groq dan Gemini gagal. Groq: ${firstError.localizedMessage}; Gemini: ${e.localizedMessage}")
                    throw e
                }
            } else if (provider == "gemini") throw IllegalStateException("Gemini API key belum diisi")
        }
        throw firstError ?: IllegalStateException("Isi minimal satu API key")
    }

    private fun requestChatCompletion(endpoint: String, model: String, apiKey: String, history: List<JSONObject>): String {
        require(model.isNotBlank()) { "Nama model belum diisi" }
        val connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 15000
            readTimeout = 45000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("Authorization", "Bearer $apiKey")
        }
        try {
            val messages = JSONArray()
            messages.put(JSONObject().put("role", "system").put("content", "Kamu adalah WINE, tutor dan teman ngobrol berbahasa Indonesia. Fokus membantu belajar sekolah, menjelaskan konsep bertahap, coding dengan contoh aman, dan pengetahuan umum. Ramah, cerdas, lucu ringan, sedikit jail tetapi tetap sopan. Untuk tugas sekolah, ajari proses berpikir dan jangan mengarang fakta. Jawab jelas dan jangan mengaku melakukan hal yang belum didukung."))
            history.takeLast(20).forEach { messages.put(it) }
            val body = JSONObject().put("model", model).put("messages", messages).put("temperature", 0.7)
            OutputStreamWriter(connection.outputStream, Charsets.UTF_8).use { it.write(body.toString()) }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val response = stream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            if (code !in 200..299) throw IllegalStateException("HTTP $code: ${response.take(220)}")
            val content = JSONObject(response).getJSONArray("choices").getJSONObject(0)
                .getJSONObject("message").optString("content").trim()
            if (content.isBlank()) throw IllegalStateException("Jawaban kosong dari AI")
            return content
        } finally { connection.disconnect() }
    }

    private fun simpleSeekListener(onChange: (Int) -> Unit) =
        object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                onChange(progress)
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        }

    private fun requestNeededPermissions() {
        val permissions = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        val missing = permissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) ActivityCompat.requestPermissions(this, missing.toTypedArray(), requestCode)
    }

    private fun startListener() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestNeededPermissions()
            status.text = "Status: izinkan mikrofon dahulu"
            return
        }
        val intent = Intent(this, VoiceService::class.java).setAction(VoiceService.ACTION_START)
        ContextCompat.startForegroundService(this, intent)
        status.text = "Status: pendengar WINE diminta aktif"
    }

    private fun stopListener() {
        startService(Intent(this, VoiceService::class.java).setAction(VoiceService.ACTION_STOP))
        status.text = "Status: pendengar dimatikan"
    }

    private fun startAlarm() {
        startService(Intent(this, VoiceService::class.java).setAction(VoiceService.ACTION_ALARM))
        status.text = "Status: alarm pencari HP aktif"
    }

    private fun stopAlarm() {
        startService(Intent(this, VoiceService::class.java).setAction(VoiceService.ACTION_ALARM_STOP))
        status.text = "Status: alarm dihentikan"
    }

    private fun startRecording() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestNeededPermissions(); return
        }
        try {
            val output = File(audioDir, "wine_${System.currentTimeMillis()}.m4a")
            recorder = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else MediaRecorder()
            recorder?.apply {
                setAudioSource(MediaRecorder.AudioSource.MIC)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setAudioEncodingBitRate(128000)
                setAudioSamplingRate(44100)
                setOutputFile(output.absolutePath)
                prepare()
                start()
            }
            selectedRecording = output
            status.text = "Status: sedang merekam… tekan Simpan rekaman"
        } catch (e: Exception) {
            status.text = "Gagal mulai rekam: ${e.localizedMessage}"
            recorder?.release(); recorder = null
        }
    }

    private fun stopRecording() {
        val active = recorder ?: return
        try {
            active.stop()
            status.text = "Status: rekaman tersimpan"
        } catch (_: Exception) {
            status.text = "Rekaman terlalu singkat atau gagal disimpan"
        } finally {
            active.release(); recorder = null; refreshRecordings()
        }
    }

    private fun refreshRecordings() {
        if (!::recordings.isInitialized) return
        val files = audioDir.listFiles()?.filter { it.isFile && it.extension == "m4a" }?.sortedByDescending { it.lastModified() } ?: emptyList()
        val names = files.map { it.name }
        recordings.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names.ifEmpty { listOf("Belum ada rekaman") })
        selectedRecording = files.firstOrNull()
        recordings.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) { selectedRecording = null }
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                selectedRecording = files.getOrNull(position)
            }
        }
    }

    private fun playSelectedRecording() {
        val file = selectedRecording
        if (file == null || !file.exists()) { speak("Belum ada rekaman."); return }
        try {
            stopPlayer()
            player = MediaPlayer().apply {
                setDataSource(file.absolutePath)
                setVolume(volume, volume)
                prepare()
                start()
            }
        } catch (e: Exception) { status.text = "Gagal memutar: ${e.localizedMessage}" }
    }

    private fun stopPlayer() {
        try { player?.stop() } catch (_: Exception) {}
        player?.release(); player = null
    }

    private fun speak(message: String) {
        if (::tts.isInitialized) tts.speak(message, TextToSpeech.QUEUE_FLUSH, null, "wine-${System.currentTimeMillis()}")
    }

    override fun onInit(result: Int) {
        if (result == TextToSpeech.SUCCESS) {
            tts.language = Locale("id", "ID")
            tts.setSpeechRate(speechRate)
            tts.setPitch(1.0f)
        }
    }

    override fun onDestroy() {
        chatExecutor.shutdownNow()
        if (::tts.isInitialized) tts.shutdown()
        stopPlayer()
        if (recorder != null) stopRecording()
        super.onDestroy()
    }
}
